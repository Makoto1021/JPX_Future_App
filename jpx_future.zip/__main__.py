from jpx_future import jpx_future

if __name__ == "__main__":
    jpx_future()